# EdgeOne Makers：原生定时直播源管理

管理页面、边缘接口、KV 和原生 `schedules` 均属于同一个 Makers 项目。使用原生定时任务，不需要 SCF 或外部 Worker。

## 从源码部署

**使用 Git 源码构建。不要使用控制台 ZIP 直接上传来部署本版定时任务。** 官方直接上传说明只支持部分 edgeone.json 字段，不包括 schedules。

1. 导入本目录为项目根目录，框架选其他。
2. 项目设置：安装命令 `npm install`，构建命令 `npm run build`，输出目录 `dist`。
3. 创建或复用 KV，绑定名称 **LIVE_KV**。复用已有站点数据时选择原命名空间。
4. 在部署前为正式环境设置以下服务端变量，变量同时用于安装/构建和函数运行：

   | 名称 | 内容 |
   | --- | --- |
   | `ADMIN_PASSWORD` | 6～1024 字符管理密码 |
   | `SESSION_SECRET` | 至少 32 字符随机会话密钥 |
   | `CRON_SECRET` | 另一个至少 32 字符随机值，用于原生任务认证 |

5. 部署后确认项目的原生定时任务包含 `refresh-sources`，每天北京时间 02:00 以 POST 触发 `/api/cron/refresh`。再访问 `/api/session` 验证未登录返回 JSON 401，登录管理页查看来源及后续更新记录。

## 原生配置与认证

`edgeone.template.json` 是可提交的配置模板，包含真正的 `schedules` 字段。`npm install` 的 `postinstall` 会在 Makers 校验配置前生成根目录 `edgeone.json`；构建时也再次生成，避免使用旧凭据。

原生任务使用官方支持的 JSON `payload`，携带从 `CRON_SECRET` 派生的专用 HMAC 凭据。接口会验证凭据后再读取到期源，不依赖登录 Cookie 或未经验证的请求头。缺少密钥会令安装/构建失败，不会静默关闭调度。修改 CRON_SECRET 后需重新部署。

生成的 `edgeone.json` 含任务专用认证信息，已被 Git 忽略，且不放入 `dist`。不要将生成后的配置作为静态文件公开，也不要提交 Git。源码包只包含模板，不包含运行密钥或生成凭据。

## 时间语义

- 本版界面按整数天设置，保留已有分钟记录的读取兼容；新建源默认 1 天。
- 原生任务每天 02:00 检查哪些源已到期。**首次到期后需等到下一次每日检查，等待可能接近 24 小时**；它不是“添加后精确满 24 小时执行”。
- 原生任务单轮读取全部到期源快照，以 3 个源为一组并行更新，不受旧外部接口每轮最多 3 个的限制。来源过多时仍受平台单次函数时长和 CPU 配额约束。
- 原生更新以当天 02:00 的计划时间计入下次到期，避免秒级投递抖动导致 1 天源跳过一整天；实际尝试/成功记录保留真实执行时间。手动更新会重新计时；来源拉取失败保留旧列表，下次到期再尝试。原生任务已运行不等于每个来源都成功，结果以每个源的更新记录为准。
- 官方配置文档当前注明最小间隔一天，因此本版采用每日任务，不承诺分钟级原生调度。每小时示例与该限制存在矛盾，分钟/小时频率需另行取得平台确认。

## 本地检查

需要 Node.js 22+。代码运行无需第三方依赖。

```powershell
npm run setup
# 编辑生成的 .env.local，填写 ADMIN_PASSWORD
npm run build
npm test
npm run dev
```

本地开发不会启动 Makers 云端定时任务。测试覆盖签名生成、伪造凭据拒绝、无需登录的原生调用、单轮全部到期源、间隔边界和旧数据兼容；生产自然触发还须在部署后观察。

参考：[原生 schedules 配置](https://pages.edgeone.ai/zh/document/edgeone-json)、[直接上传限制](https://pages.edgeone.ai/zh/document/direct-upload)。

## 机顶盒订阅兼容性

所有订阅支持 GET、HEAD 和 OPTIONS；HEAD 返回对应完整文件的 UTF-8 字节长度，不发送正文。`playlist.m3u8` 是 `playlist.m3u` 的等价地址，共用禁用、到期及改名控制，现有链接继续有效。

订阅下载支持单段字节 Range（206 / 416）和跨域读取，包含错误响应；管理 API 的登录与跨域限制保持原有设置。不支持的多段 Range 返回完整文件；带 If-Range 时返回完整文件，避免把不同版本片段拼接。

部署后应对实际域名验证 GET / HEAD 的 Content-Length 一致、Range 返回 206，再在机顶盒重新加载订阅。源列表相同不代表所有设备都能连接域名或播放其中每条直播流。

### EdgeOne HEAD 平台适配（第二版）

此前共用处理器给 HEAD 构造空 Response，即使显式指定完整文件长度，EdgeOne 线上仍返回 Content-Length: 0；同样代码在 Cloudflare 返回正确长度。第二版在 `edge-functions/sub/[[path]].js` 中将 HEAD 内部转换为忽略 Range 的 GET，以完整表示构造 Response，让平台根据完整正文计算长度，并由原始 HEAD 请求的 HTTP 发送层抑制正文。转换只发生在只读订阅入口，仍执行原有订阅校验。

34 项本地测试通过，新增测试覆盖平台入口和模拟重算长度的 HTTP 发送层；该模拟不能代替 EdgeOne 真实运行时验证。部署后必须验证 HEAD 的状态为 200、Content-Length 等于同一版本 GET 的实际字节数且线上正文为空，再用机顶盒复测。若依旧为零，需要进一步检查平台发送层，不能宣称已修复线上问题。


## M3U 输出格式

M3U/M3U8 按 https://live.zbds.top/tv/iptv4.m3u 的结构输出 tvg-name、tvg-id、tvg-logo 和 group-title。保留来源 EPG、额外属性及播放参数，缺失的 EPG 标识和台标留空。响应类型为 audio/x-mpegurl; charset=utf-8。部署后现有链接直接生效。
