import { handle } from '../../lib/server.js';
import { hasKV } from '../../lib/kv.js';
export async function onRequest(context) {
  const injected = typeof LIVE_KV !== 'undefined' ? LIVE_KV : globalThis.LIVE_KV;
  return handle(context, hasKV(injected) ? injected : context.env?.LIVE_KV);
}
export default onRequest;
