import { handle } from '../../lib/server.js';
import { hasKV } from '../../lib/kv.js';
export async function onRequest(context) {
  const injected = typeof LIVE_KV !== 'undefined' ? LIVE_KV : globalThis.LIVE_KV;
  const kv = hasKV(injected) ? injected : context.env?.LIVE_KV;
  if (context.request.method === 'HEAD') {
    // EdgeOne emits Content-Length: 0 for a null Response body, even when the
    // handler supplies the GET length. Keep the complete representation until
    // the platform's HTTP layer suppresses the body for the original HEAD.
    // Range has no meaning for HEAD and must not turn the metadata into a 206.
    const headers = new Headers(context.request.headers);
    headers.delete('Range');
    headers.delete('If-Range');
    const request = new Request(context.request, { method: 'GET', headers });
    return handle({ ...context, request }, kv);
  }
  return handle(context, kv);
}
export default onRequest;
