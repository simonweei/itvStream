import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { nativeScheduleToken } from '../lib/native-schedule.js';

export async function prepareSchedules({ directory = process.cwd(), secret = process.env.CRON_SECRET } = {}) {
  const config = JSON.parse(await readFile(resolve(directory, 'edgeone.template.json'), 'utf8'));
  const task = config.schedules?.find(item => item.path === '/api/cron/refresh');
  if (!task || task.method !== 'POST' || !task.cron || !task.timezone) throw new Error('缺少有效的原生定时任务配置');
  task.payload = { token: await nativeScheduleToken(secret) };
  // Outside dist and ignored by Git. Never publish this file as a static asset.
  await writeFile(resolve(directory, 'edgeone.json'), JSON.stringify(config, null, 2) + '\n', { mode: 0o600 });
  return config;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    await prepareSchedules();
    console.log('已生成 EdgeOne 原生定时配置，凭据未输出。');
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
