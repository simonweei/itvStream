import { writeFile, access } from 'node:fs/promises';
import { randomHex } from '../lib/auth.js';
try {
  let exists = false; try { await access('.env.local'); exists = true; } catch {}
  if (exists) throw new Error('.env.local 已存在。为避免覆盖现有配置，请先备份并移走该文件。');
  await writeFile('.env.local', `ADMIN_PASSWORD=\nSESSION_SECRET=${randomHex()}\nCRON_SECRET=${randomHex()}\n`, { flag: 'wx', mode: 0o600 });
  console.log('已生成 .env.local（已被 Git 忽略）。请直接编辑 ADMIN_PASSWORD 设置登录密码（至少 6 个字符）。线上也可以直接在 EdgeOne 环境变量中设置，无需运行 setup。');
} catch (error) { console.error(error.message); process.exitCode = 1; }
