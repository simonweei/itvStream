import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, copyFile, readFile, rm, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { prepareSchedules } from '../scripts/prepare-schedules.mjs';
import { nativeScheduleToken } from '../lib/native-schedule.js';

test('原生配置生成每日 POST 任务，仅携带派生凭据；缺少密钥时关闭部署', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'iptv-native-'));
  try {
    await copyFile(new URL('../edgeone.template.json', import.meta.url), join(directory, 'edgeone.template.json'));
    await assert.rejects(prepareSchedules({ directory, secret: '' }), /CRON_SECRET/);
    await assert.rejects(access(join(directory, 'edgeone.json')));
    const secret = 'test-only-native-secret-'.repeat(3);
    const config = await prepareSchedules({ directory, secret });
    const task = config.schedules[0];
    assert.equal(task.cron, '0 2 * * *');
    assert.equal(task.timezone, 'Asia/Shanghai');
    assert.equal(task.method, 'POST');
    assert.equal(task.path, '/api/cron/refresh');
    assert.equal(task.payload.token, await nativeScheduleToken(secret));
    assert.equal((await readFile(join(directory, 'edgeone.json'), 'utf8')).includes(secret), false);
    assert.notEqual(task.payload.token, await nativeScheduleToken('another-test-secret-'.repeat(3)));
  } finally { await rm(directory, { recursive: true, force: true }); }
});
